This code is a simple implementation of [1], [2]. 
The function trmszc  implements the main algorithm. 
See the comments in the start of this file in order to execute it. 


It yields a sound segmentation and classification (classes: music, voice, silence) 
with 20 msec accuracy.

For more details, you can visit www.csd.uoc.gr/~cpanag and www.csd.uoc.gr/~tziritas
 
You can use this software for non commercial purposes. 
Please, if you use it, cite the articles [1], [2].

[1]. C. Panagiotakis and G. Tziritas, A speech/music discriminator based on 
RMS and zero-crossings, IEEE Transactions on Multimedia, Vol. 7, No. 1, Feb. 2005.

[2] C. Panagiotakis and G. Tziritas, A Speech/Music Discriminator using 
RMS and Zero-crossings, European Signal Processing Conference, 2002.